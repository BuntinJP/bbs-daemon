import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import request from 'superagent';
import { Button } from 'react-bootstrap';
import App from './component/App.js';

ReactDOM.render(<App />, document.getElementById('app'));
