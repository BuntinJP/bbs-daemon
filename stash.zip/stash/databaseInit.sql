create database bbs;

use bbs;

create table log (
    id int,
    name varchar(100),
    body varchar(10000),
    date varchar(100)
);

exit;